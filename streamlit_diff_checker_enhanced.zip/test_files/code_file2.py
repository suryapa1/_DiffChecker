def calculate_sum(a, b):
    # This function calculates the sum of two numbers
    return a + b

def calculate_difference(a, b):
    # This function calculates the difference between two numbers
    return a - b
    
def calculate_product(a, b):
    # This function calculates the product of two numbers
    return a * b

# Main function
def main():
    x = 10
    y = 5
    print(f"Sum: {calculate_sum(x, y)}")
    print(f"Difference: {calculate_difference(x, y)}")
    print(f"Product: {calculate_product(x, y)}")

if __name__ == "__main__":
    main()
