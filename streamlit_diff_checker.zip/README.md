# Streamlit Diff Checker Application - User Guide

## Overview

The Streamlit Diff Checker is a powerful application for comparing text and code files, similar to Beyond Compare. It allows you to upload files or folders, view differences, make changes in either direction, and generate reconciled output files.

## Features

- **Dual-pane Interface**: Upload and compare files side by side
- **File and Folder Support**: Upload individual files or entire folders (as ZIP)
- **Diff Visualization**: Line-by-line comparison with color-coded differences
- **Syntax Highlighting**: Proper highlighting for various code file types
- **Reconciliation Controls**: Apply changes from left to right or right to left
- **Selective Reconciliation**: Choose specific changes to apply
- **Output Generation**: Create reconciled files from your comparisons
- **Download and Save**: Download reconciled files or save them to the project folder

## Installation and Setup

1. Ensure you have Python 3.6+ installed on your system
2. Clone or download the application files
3. Install the required dependencies:

```bash
pip install -r requirements.txt
```

4. Run the application:

```bash
streamlit run app.py
```

## Usage Guide

### 1. Uploading Files

- **Individual Files**: Select "File" from the radio buttons and use the file uploader
- **Folders**: Select "Folder (ZIP)" and upload a ZIP file containing multiple files
- Files will appear in the file selector dropdown once uploaded

### 2. Comparing Files

- Select files from both the left and right panes
- The diff view will automatically display differences between the selected files
- Differences are color-coded:
  - Green: Lines only in the right file
  - Red: Lines only in the left file
  - Yellow: Modified lines

### 3. Reconciling Differences

- **Apply All Changes**: Use the "Apply Left to Right" or "Apply Right to Left" buttons to apply all changes
- **Selective Changes**: Click on specific lines in the diff view to select them, then use "Apply Selected Changes"
- The reconciled text will appear in the preview area below

### 4. Saving and Downloading

- **Download**: Click the "Download Reconciled File" link to download the reconciled file
- **Save to Project**: Click "Save to Project Folder" to save the file to the application's output directory

## File Types Supported

The application supports various text and code file types, including:

- Plain text files (.txt)
- Python files (.py)
- JavaScript files (.js)
- HTML files (.html)
- CSS files (.css)
- Markdown files (.md)
- JSON files (.json)
- XML files (.xml)
- And many other text-based file formats

## Tips and Best Practices

- For comparing entire projects, organize files in folders and zip them before uploading
- Use selective reconciliation for complex files where you only want to apply specific changes
- The application works best with text and code files; binary files are not supported
- For large files, be patient as the diff generation may take a moment

## Troubleshooting

- If a file fails to upload, ensure it's a text-based file and not binary
- If the diff view doesn't appear, check that files are selected on both sides
- If the application seems slow, try with smaller files or fewer files at once

## Project Structure

```
streamlit_diff_checker/
├── app.py                  # Main Streamlit application
├── requirements.txt        # Project dependencies
├── utils/
│   ├── __init__.py
│   ├── diff_utils.py       # Diff generation and processing
│   └── file_utils.py       # File handling utilities
├── output/                 # Directory for saved reconciled files
└── test_files/             # Sample files for testing
```

## Extending the Application

The application is designed to be modular and extensible. To add new features:

- Add new utility functions in the utils directory
- Modify the main app.py file to incorporate new UI elements
- Update the CSS styling for visual enhancements

## License

This application is provided as-is for your use and modification.
